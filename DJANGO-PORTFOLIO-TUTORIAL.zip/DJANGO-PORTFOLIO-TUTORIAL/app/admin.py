from django.contrib import admin
#管理画面でデータを登録できるようにする
from .models import Profile

admin.site.register(Profile)
#モデルを作成したのでマイグレーションでデータベースを再構築していく必要がある
# python3 manage.py makemigrations
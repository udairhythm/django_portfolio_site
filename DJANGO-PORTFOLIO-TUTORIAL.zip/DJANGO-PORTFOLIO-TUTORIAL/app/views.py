# トップページ用のViewを作成
from django.shortcuts import render
from django.views.generic import View
from .models import Profile

class IndexView(View):
    def get(self, request, *args, **kwargs):
        profile_data = Profile.objects.all() # すべてのProfileデータを取得
        if profile_data.exists(): # もしProfileデータが存在したら
            profile_data = profile_data.order_by('-id')[0] # Profile_data IDをつかって降順に並び替え最新を取得
        return render(request, 'app/index.html', {
            'profile_data': profile_data # profileデータをindex.htmlにわたす
        })